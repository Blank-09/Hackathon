const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import HomePage from "./screens/HomePage";
import DrawerMenu from "./screens/DrawerMenu";
import SplashScreenPage from "./screens/SplashScreenPage";
import SearchTask from "./screens/SearchTask";
import CreateNewTask from "./screens/CreateNewTask";
import TaskPage from "./screens/TaskPage";
import DrawerMenuPage from "./screens/DrawerMenuPage";
import SplashScreen from "./screens/SplashScreen";
import NavButton7 from "./components/NavButton7";
import NavButton6 from "./components/NavButton6";
import NavButton5 from "./components/NavButton5";
import NavButton4 from "./components/NavButton4";
import NavButton3 from "./components/NavButton3";
import NavButton2 from "./components/NavButton2";
import NavButton1 from "./components/NavButton1";
import NavButton from "./components/NavButton";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

const Tab = createBottomTabNavigator();
function BottomTabsRoot({ navigation }) {
  const [bottomTabItemsNormal] = React.useState([
    <NavButton6 />,
    <NavButton4 />,
    <NavButton2 />,
    <NavButton />,
  ]);
  const [bottomTabItemsActive] = React.useState([
    <NavButton7 />,
    <NavButton5 />,
    <NavButton3 />,
    <NavButton1 />,
  ]);
  return (
    <Tab.Navigator
      screenOptions={{ headerShown: false }}
      tabBar={({ state, descriptors, navigation }) => {
        const activeIndex = state.index;
        return (
          <View
            style={{
              alignSelf: "stretch",
              borderTopLeftRadius: 10,
              borderTopRightRadius: 10,
              backgroundColor: "#fff",
              shadowColor: "rgba(188, 196, 216, 0.2)",
              shadowOffset: {
                width: 0,
                height: -3,
              },
              shadowRadius: 20,
              elevation: 20,
              shadowOpacity: 1,
              flexDirection: "row",
              paddingHorizontal: 30,
              paddingVertical: 10,
              boxSizing: "border-box",
              alignItems: "center",
              justifyContent: "center",
              height: 64,
            }}
          >
            {bottomTabItemsNormal.map((item, index) => {
              const isFocused = state.index === index;
              return (
                <Pressable
                  style={{ flex: 1 }}
                  onPress={() => {
                    navigation.navigate({
                      name: state.routes[index].name,
                      merge: true,
                    });
                  }}
                >
                  {activeIndex === index
                    ? bottomTabItemsActive[index] || item
                    : item}
                </Pressable>
              );
            })}
          </View>
        );
      }}
    >
      <Tab.Screen
        name="HomePage"
        component={HomePage}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="TaskPage"
        component={TaskPage}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="CreateNewTask"
        component={CreateNewTask}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="SearchTask"
        component={SearchTask}
        options={{ headerShown: false }}
      />
    </Tab.Navigator>
  );
}

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(false);
  const SplashScreen = () => {
    return <SplashScreenPage />;
  };
  React.useEffect(() => {
    setTimeout(() => {
      setHideSplashScreen(true);
    }, 2000);
  }, []);

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="BottomTabsRoot" component={BottomTabsRoot} />
            <Stack.Screen
              name="SplashScreenPage"
              component={SplashScreenPage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="DrawerMenuPage"
              component={DrawerMenuPage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen"
              component={SplashScreen}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : (
          <SplashScreen />
        )}
      </NavigationContainer>
    </>
  );
};
export default App;
