import * as React from "react";
import {
  StyleProp,
  ViewStyle,
  Image,
  StyleSheet,
  Text,
  View,
} from "react-native";

const MenuItem10 = ({ style }) => {
  return (
    <View style={[styles.menuItemView, style]}>
      <Image
        style={styles.iconlyLightFilter}
        resizeMode="cover"
        source={require("../assets/iconlylightfilter.png")}
      />
      <Text style={[styles.categoriesText, styles.ml16]}>Categories</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  ml16: {
    marginLeft: 16,
  },
  iconlyLightFilter: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  categoriesText: {
    position: "relative",
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: "Roboto",
    color: "#191919",
    textAlign: "left",
  },
  menuItemView: {
    alignSelf: "stretch",
    position: "relative",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
});

export default MenuItem10;
