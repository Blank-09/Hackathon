import * as React from "react";
import {
  Pressable,
  StyleProp,
  ViewStyle,
  Image,
  StyleSheet,
  Text,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const MenuItem5 = ({ style }) => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={[styles.menuItem5Pressable, style]}
      onPress={() =>
        navigation.navigate("BottomTabsRoot", { screen: "SearchTask" })
      }
    >
      <Image
        style={styles.ionmailOutlineIcon}
        resizeMode="cover"
        source={require("../assets/ionmailoutline.png")}
      />
      <Text style={[styles.getHelpText, styles.ml16]}>Get Help</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  ml16: {
    marginLeft: 16,
  },
  ionmailOutlineIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  getHelpText: {
    position: "relative",
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: "Roboto",
    color: "#191919",
    textAlign: "left",
  },
  menuItem5Pressable: {
    alignSelf: "stretch",
    position: "relative",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
});

export default MenuItem5;
