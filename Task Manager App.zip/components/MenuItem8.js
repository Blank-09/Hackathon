import * as React from "react";
import {
  StyleProp,
  ViewStyle,
  Image,
  StyleSheet,
  Text,
  View,
} from "react-native";

const MenuItem8 = ({ style }) => {
  return (
    <View style={[styles.menuItemView, style]}>
      <Image
        style={styles.ionmailOutlineIcon}
        resizeMode="cover"
        source={require("../assets/ionmailoutline.png")}
      />
      <Text style={[styles.getHelpText, styles.ml16]}>Get Help</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  ml16: {
    marginLeft: 16,
  },
  ionmailOutlineIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  getHelpText: {
    position: "relative",
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "500",
    fontFamily: "Roboto",
    color: "#191919",
    textAlign: "left",
  },
  menuItemView: {
    alignSelf: "stretch",
    position: "relative",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
});

export default MenuItem8;
