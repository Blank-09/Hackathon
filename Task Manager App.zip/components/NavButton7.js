import * as React from "react";
import {
  Pressable,
  StyleProp,
  ViewStyle,
  Image,
  StyleSheet,
  View,
} from "react-native";

const NavButton7 = ({ style }) => {
  return (
    <Pressable style={[styles.navButtonPressable, style]}>
      <View style={styles.btnContainerView}>
        <Image
          style={styles.homeIcon}
          resizeMode="cover"
          source={require("../assets/home.png")}
        />
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  homeIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView: {
    flex: 1,
    alignSelf: "stretch",
    borderRadius: 50,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable: {
    position: "relative",
    borderRadius: 100,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "center",
  },
});

export default NavButton7;
