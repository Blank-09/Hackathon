import * as React from "react";
import {
  StyleProp,
  ViewStyle,
  Pressable,
  Image,
  StyleSheet,
  View,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const NavigationBarSquare4 = ({ style }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.navigationBarSquareView, style]}>
      <View style={styles.activehomeView}>
        <Pressable
          style={styles.navButtonPressable}
          onPress={() =>
            navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
          }
        >
          <View style={styles.btnContainerView}>
            <Image
              style={styles.homeIcon}
              resizeMode="cover"
              source={require("../assets/home40.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable1}>
          <View style={styles.btnContainerView1}>
            <Image
              style={styles.calendarIcon}
              resizeMode="cover"
              source={require("../assets/home41.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable2}>
          <View style={styles.btnContainerView2}>
            <Image
              style={styles.plusIcon}
              resizeMode="cover"
              source={require("../assets/home42.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable3}>
          <View style={styles.btnContainerView3}>
            <Image
              style={styles.searchIcon}
              resizeMode="cover"
              source={require("../assets/home43.png")}
            />
          </View>
        </Pressable>
      </View>
      <View style={[styles.activetaskView, styles.mt20]}>
        <Pressable style={styles.navButtonPressable4} onPress={() => {}}>
          <View style={styles.btnContainerView4}>
            <Image
              style={styles.homeIcon1}
              resizeMode="cover"
              source={require("../assets/home44.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable5}>
          <View style={styles.btnContainerView5}>
            <Image
              style={styles.calendarIcon1}
              resizeMode="cover"
              source={require("../assets/home45.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable6}>
          <View style={styles.btnContainerView6}>
            <Image
              style={styles.plusIcon1}
              resizeMode="cover"
              source={require("../assets/home42.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable7}>
          <View style={styles.btnContainerView7}>
            <Image
              style={styles.searchIcon1}
              resizeMode="cover"
              source={require("../assets/home43.png")}
            />
          </View>
        </Pressable>
      </View>
      <View style={[styles.activeaddView, styles.mt20]}>
        <Pressable style={styles.navButtonPressable8}>
          <View style={styles.btnContainerView8}>
            <Image
              style={styles.homeIcon2}
              resizeMode="cover"
              source={require("../assets/home44.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable9}>
          <View style={styles.btnContainerView9}>
            <Image
              style={styles.calendarIcon2}
              resizeMode="cover"
              source={require("../assets/home41.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable10}>
          <View style={styles.btnContainerView10}>
            <Image
              style={styles.plusIcon2}
              resizeMode="cover"
              source={require("../assets/home50.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable11}>
          <View style={styles.btnContainerView11}>
            <Image
              style={styles.searchIcon2}
              resizeMode="cover"
              source={require("../assets/home43.png")}
            />
          </View>
        </Pressable>
      </View>
      <View style={[styles.activesearchView, styles.mt20]}>
        <Pressable style={styles.navButtonPressable12}>
          <View style={styles.btnContainerView12}>
            <Image
              style={styles.homeIcon3}
              resizeMode="cover"
              source={require("../assets/home44.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable13}>
          <View style={styles.btnContainerView13}>
            <Image
              style={styles.calendarIcon3}
              resizeMode="cover"
              source={require("../assets/home41.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable14}>
          <View style={styles.btnContainerView14}>
            <Image
              style={styles.plusIcon3}
              resizeMode="cover"
              source={require("../assets/home42.png")}
            />
          </View>
        </Pressable>
        <Pressable style={styles.navButtonPressable15}>
          <View style={styles.btnContainerView15}>
            <Image
              style={styles.searchIcon3}
              resizeMode="cover"
              source={require("../assets/home55.png")}
            />
          </View>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  mt20: {
    marginTop: 20,
  },
  homeIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView: {
    flex: 1,
    alignSelf: "stretch",
    borderRadius: 50,
    backgroundColor: "#5e41fc",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable: {
    borderRadius: 100,
    backgroundColor: "#5e41fc",
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  calendarIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView1: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable1: {
    borderRadius: 100,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  plusIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView2: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable2: {
    borderRadius: 100,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  searchIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView3: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable3: {
    borderRadius: 100,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  activehomeView: {
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "rgba(188, 196, 216, 0.2)",
    shadowOffset: {
      width: 0,
      height: -3,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 390,
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "space-between",
  },
  homeIcon1: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView4: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable4: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  calendarIcon1: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView5: {
    flex: 1,
    alignSelf: "stretch",
    borderRadius: 50,
    backgroundColor: "#5e41fc",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable5: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  plusIcon1: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView6: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable6: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  searchIcon1: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView7: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable7: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  activetaskView: {
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "rgba(188, 196, 216, 0.2)",
    shadowOffset: {
      width: 0,
      height: -3,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 390,
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "space-between",
  },
  homeIcon2: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView8: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable8: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  calendarIcon2: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView9: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable9: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  plusIcon2: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView10: {
    flex: 1,
    alignSelf: "stretch",
    borderRadius: 50,
    backgroundColor: "#5e41fc",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable10: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  searchIcon2: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView11: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable11: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  activeaddView: {
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "rgba(188, 196, 216, 0.2)",
    shadowOffset: {
      width: 0,
      height: -3,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 390,
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "space-between",
  },
  homeIcon3: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView12: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable12: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  calendarIcon3: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView13: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable13: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  plusIcon3: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView14: {
    flex: 1,
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable14: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  searchIcon3: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  btnContainerView15: {
    flex: 1,
    alignSelf: "stretch",
    borderRadius: 50,
    backgroundColor: "#5e41fc",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  navButtonPressable15: {
    borderRadius: 50,
    width: 44,
    height: 44,
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  activesearchView: {
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "rgba(188, 196, 216, 0.2)",
    shadowOffset: {
      width: 0,
      height: -3,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 390,
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "space-between",
  },
  navigationBarSquareView: {
    position: "relative",
    borderRadius: 5,
    borderStyle: "dashed",
    borderColor: "#9747ff",
    borderWidth: 1,
    flexDirection: "column",
    padding: 20,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default NavigationBarSquare4;
