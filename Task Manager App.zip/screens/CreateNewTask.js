import * as React from "react";
import { useCallback } from "react";
import {
  StatusBar,
  StyleSheet,
  Pressable,
  Image,
  Text,
  View,
  ScrollView,
  TouchableHighlight,
  Alert,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const CreateNewTask = () => {
  const navigation = useNavigation();

  const onCreateTaskBtnButtonClick = useCallback(() => {
    Alert.alert("Task Created", "You're Task is Created Successfully", [
      {
        text: "Close",
        onPress: () => console.log("Close pressed"),
      },
    ]);
  }, []);

  return (
    <View style={styles.createNewTask}>
      <StatusBar
        barStyle="light-content"
        translucent={true}
        backgroundColor="#303030"
      />
      <View style={styles.navBarView}>
        <Pressable
          style={styles.arrowLeftPressable}
          onPress={() => navigation.goBack()}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/arrowleft.png")}
          />
        </Pressable>
        <Text style={styles.taskManagerText}>Create New Task</Text>
        <Image
          style={styles.searchIcon}
          resizeMode="cover"
          source={require("../assets/search1.png")}
        />
      </View>
      <ScrollView
        style={styles.mainBodyScrollView}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.mainBodyScrollViewContent}
      >
        <View style={styles.inputContainerView}>
          <View style={styles.inputStandardView}>
            <View style={styles.standardView}>
              <Text style={styles.titleText}>Title</Text>
              <View style={[styles.contentView, styles.mt5_5]}>
                <Text style={styles.taskNameText}>Task Name</Text>
              </View>
              <Image
                style={[styles.underlineIcon, styles.mt5_5]}
                resizeMode="cover"
                source={require("../assets/underline.png")}
              />
            </View>
          </View>
          <View style={[styles.dateTimePicker, styles.mt32]}>
            <Text style={styles.dateText}>Date</Text>
            <View style={[styles.contentView1, styles.mt7]}>
              <Text style={styles.text}>01/01/2022</Text>
              <Image
                style={[styles.vectorIcon, styles.ml8]}
                resizeMode="cover"
                source={require("../assets/vector1.png")}
              />
            </View>
            <View style={[styles.lineView, styles.mt7]} />
          </View>
          <View style={[styles.groupContainerView, styles.mt32]}>
            <View style={styles.timePickerView2}>
              <View style={styles.timePickerView}>
                <Text style={styles.startTimeText}>Start Time</Text>
                <View style={[styles.contentView2, styles.mt6]}>
                  <Text style={styles.pMText}>12:00 PM</Text>
                  <Image
                    style={[styles.vectorIcon1, styles.ml8]}
                    resizeMode="cover"
                    source={require("../assets/vector2.png")}
                  />
                </View>
                <View style={[styles.lineView1, styles.mt6]} />
              </View>
              <View style={[styles.timePickerView1, styles.ml41]}>
                <Text style={styles.endTimeText}>End Time</Text>
                <View style={[styles.contentView3, styles.mt6]}>
                  <Text style={styles.pMText1}>12:00 PM</Text>
                  <Image
                    style={[styles.vectorIcon2, styles.ml8]}
                    resizeMode="cover"
                    source={require("../assets/vector3.png")}
                  />
                </View>
                <View style={[styles.lineView2, styles.mt6]} />
              </View>
            </View>
            <View style={[styles.textAreaStandardView, styles.mt30]}>
              <View style={styles.standardView1}>
                <Text style={styles.descriptionText}>Description</Text>
                <View style={[styles.contentView4, styles.mt13_5]}>
                  <Text style={styles.someTextHereForTheDescrip}>
                    Some text here for the description. Description will give
                    you details about the task.
                  </Text>
                </View>
                <Image
                  style={[styles.underlineIcon1, styles.mt13_5]}
                  resizeMode="cover"
                  source={require("../assets/underline1.png")}
                />
              </View>
            </View>
          </View>
        </View>
        <View style={styles.categoryDivView}>
          <View style={styles.titleView}>
            <Text style={styles.categoryText}>Category</Text>
          </View>
          <View style={[styles.categoriesChoiceView, styles.mt22]}>
            <View style={styles.groupView}>
              <Pressable style={styles.categoryBadgesPressable}>
                <Text style={styles.marketingText}>Marketing</Text>
              </Pressable>
              <Pressable style={[styles.categoryBadgesPressable1, styles.ml25]}>
                <Text style={styles.marketingText1}>Meeting</Text>
              </Pressable>
              <Pressable style={[styles.categoryBadgesPressable2, styles.ml25]}>
                <Text style={styles.marketingText2}>Production</Text>
              </Pressable>
            </View>
            <View style={[styles.group2View, styles.mt13]}>
              <Pressable style={styles.categoryBadgesPressable3}>
                <Text style={styles.marketingText3}>Dev</Text>
              </Pressable>
              <Pressable style={[styles.categoryBadgesPressable4, styles.ml19]}>
                <Text style={styles.marketingText4}>Dashboard Design</Text>
              </Pressable>
              <Pressable style={[styles.categoryBadgesPressable5, styles.ml19]}>
                <Text style={styles.marketingText5}>UI Design</Text>
              </Pressable>
            </View>
          </View>
        </View>
        <View style={styles.createButtonView}>
          <TouchableHighlight
            style={styles.createTaskBtnTouchableHighlight}
            underlayColor="#4e00e2"
            onPress={onCreateTaskBtnButtonClick}
          >
            <Text style={styles.text1}>Create Task</Text>
          </TouchableHighlight>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  mt5_5: {
    marginTop: 5.5,
  },
  ml8: {
    marginLeft: 8,
  },
  mt7: {
    marginTop: 7,
  },
  mt6: {
    marginTop: 6,
  },
  ml41: {
    marginLeft: 41,
  },
  mt13_5: {
    marginTop: 13.5,
  },
  mt30: {
    marginTop: 30,
  },
  mt32: {
    marginTop: 32,
  },
  ml25: {
    marginLeft: 25,
  },
  ml19: {
    marginLeft: 19,
  },
  mt13: {
    marginTop: 13,
  },
  mt22: {
    marginTop: 22,
  },
  mainBodyScrollViewContent: {
    alignItems: "flex-start",
    justifyContent: "flex-start",
    flexDirection: "column",
  },
  ml45: {
    marginLeft: 45,
  },
  icon: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  arrowLeftPressable: {
    position: "relative",
  },
  taskManagerText: {
    position: "relative",
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Roboto",
    color: "#000",
    textAlign: "center",
  },
  searchIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  navBarView: {
    alignSelf: "stretch",
    backgroundColor: "#fff",
    shadowColor: "rgba(215, 215, 215, 0.25)",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 20,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "space-between",
  },
  titleText: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    lineHeight: 12,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.42)",
    textAlign: "left",
  },
  taskNameText: {
    flex: 1,
    position: "relative",
    fontSize: 16,
    letterSpacing: 0.15,
    lineHeight: 24,
    fontFamily: "Roboto",
    color: "#000",
    textAlign: "left",
  },
  contentView: {
    alignSelf: "stretch",
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  underlineIcon: {
    alignSelf: "stretch",
    position: "relative",
    maxWidth: "100%",
    height: 2,
    flexShrink: 0,
  },
  standardView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  inputStandardView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  dateText: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    lineHeight: 12,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.42)",
    textAlign: "left",
  },
  text: {
    flex: 1,
    position: "relative",
    fontSize: 16,
    letterSpacing: 0.15,
    lineHeight: 24,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.87)",
    textAlign: "left",
  },
  vectorIcon: {
    position: "relative",
    width: 20,
    height: 22,
    flexShrink: 0,
    overflow: "hidden",
  },
  contentView1: {
    alignSelf: "stretch",
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  lineView: {
    alignSelf: "stretch",
    position: "relative",
    borderStyle: "solid",
    borderColor: "rgba(0, 0, 0, 0.3)",
    borderWidth: 1,
    height: 2,
    flexShrink: 0,
  },
  dateTimePicker: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  startTimeText: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    lineHeight: 12,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.4)",
    textAlign: "left",
  },
  pMText: {
    flex: 1,
    position: "relative",
    fontSize: 16,
    letterSpacing: 0.15,
    lineHeight: 24,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.87)",
    textAlign: "left",
  },
  vectorIcon1: {
    position: "relative",
    width: 21,
    height: 20,
    flexShrink: 0,
  },
  contentView2: {
    alignSelf: "stretch",
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  lineView1: {
    alignSelf: "stretch",
    position: "relative",
    borderStyle: "solid",
    borderColor: "#000",
    borderWidth: 1,
    height: 2,
    flexShrink: 0,
  },
  timePickerView: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  endTimeText: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    lineHeight: 12,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.4)",
    textAlign: "left",
  },
  pMText1: {
    flex: 1,
    position: "relative",
    fontSize: 16,
    letterSpacing: 0.15,
    lineHeight: 24,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.87)",
    textAlign: "left",
  },
  vectorIcon2: {
    position: "relative",
    width: 21,
    height: 20,
    flexShrink: 0,
  },
  contentView3: {
    alignSelf: "stretch",
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  lineView2: {
    alignSelf: "stretch",
    position: "relative",
    borderStyle: "solid",
    borderColor: "#000",
    borderWidth: 1,
    height: 2,
    flexShrink: 0,
  },
  timePickerView1: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  timePickerView2: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  descriptionText: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    lineHeight: 12,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.4)",
    textAlign: "left",
  },
  someTextHereForTheDescrip: {
    flex: 1,
    position: "relative",
    fontSize: 16,
    letterSpacing: 0.15,
    lineHeight: 24,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.87)",
    textAlign: "left",
  },
  contentView4: {
    alignSelf: "stretch",
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  underlineIcon1: {
    alignSelf: "stretch",
    position: "relative",
    maxWidth: "100%",
    height: 2,
    flexShrink: 0,
  },
  standardView1: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  textAreaStandardView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  groupContainerView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  inputContainerView: {
    alignSelf: "stretch",
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingVertical: 40,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  categoryText: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 24,
    letterSpacing: 0.15,
    fontWeight: "600",
    fontFamily: "Roboto",
    color: "#000",
    textAlign: "left",
  },
  titleView: {
    alignSelf: "stretch",
    position: "relative",
    height: 28,
    flexShrink: 0,
  },
  marketingText: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    fontWeight: "300",
    fontFamily: "Roboto",
    color: "#282828",
    textAlign: "center",
  },
  categoryBadgesPressable: {
    flex: 1,
    borderRadius: 8,
    backgroundColor: "#c8d7f7",
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  marketingText1: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    fontWeight: "600",
    fontFamily: "Roboto",
    color: "#fff",
    textAlign: "center",
  },
  categoryBadgesPressable1: {
    flex: 1,
    borderRadius: 8,
    backgroundColor: "#6040f8",
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  marketingText2: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    fontWeight: "300",
    fontFamily: "Roboto",
    color: "#282828",
    textAlign: "center",
  },
  categoryBadgesPressable2: {
    flex: 1,
    borderRadius: 8,
    backgroundColor: "#c8d7f7",
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  groupView: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  marketingText3: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    fontWeight: "300",
    fontFamily: "Roboto",
    color: "#282828",
    textAlign: "center",
  },
  categoryBadgesPressable3: {
    flex: 1,
    borderRadius: 8,
    backgroundColor: "#c8d7f7",
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  marketingText4: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    fontWeight: "300",
    fontFamily: "Roboto",
    color: "#282828",
    textAlign: "center",
  },
  categoryBadgesPressable4: {
    borderRadius: 8,
    backgroundColor: "#c8d7f7",
    width: 129.33,
    flexShrink: 0,
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  marketingText5: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    fontWeight: "300",
    fontFamily: "Roboto",
    color: "#282828",
    textAlign: "center",
  },
  categoryBadgesPressable5: {
    flex: 1,
    borderRadius: 8,
    backgroundColor: "#c8d7f7",
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  group2View: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  categoriesChoiceView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  categoryDivView: {
    alignSelf: "stretch",
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingVertical: 0,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  text1: {
    position: "relative",
    fontSize: 19,
    letterSpacing: 0.15,
    fontWeight: "700",
    fontFamily: "Roboto",
    color: "#fff",
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 115.66,
    height: 24.7,
  },
  createTaskBtnTouchableHighlight: {
    alignSelf: "stretch",
    borderRadius: 25,
    backgroundColor: "#603ffa",
    borderStyle: "solid",
    borderColor: "#4e00e2",
    borderWidth: 1,
    position: "relative",
    flexDirection: "row",
    paddingHorizontal: 0,
    paddingVertical: 15,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  createButtonView: {
    alignSelf: "stretch",
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingVertical: 16,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  mainBodyScrollView: {
    alignSelf: "stretch",
    flex: 1,
  },
  createNewTask: {
    position: "relative",
    backgroundColor: "#fff",
    flex: 1,
    width: "100%",
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
});

export default CreateNewTask;
