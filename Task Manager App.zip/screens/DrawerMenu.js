import * as React from "react";
import { useState } from "react";
import MenuItem1 from "../components/MenuItem1";
import MenuItem2 from "../components/MenuItem2";
import MenuItem3 from "../components/MenuItem3";
import MenuItem4 from "../components/MenuItem4";
import MenuItem5 from "../components/MenuItem5";
import MenuItem6 from "../components/MenuItem6";
import {
  Pressable,
  Image,
  StyleSheet,
  View,
  Text,
  SafeAreaView,
} from "react-native";

const DrawerMenu = ({ state, navigation }) => {
  const [drawerItemsNormal] = useState([
    <MenuItem1 style={styles.mt28} />,
    <MenuItem2 style={styles.mt28} />,
    <MenuItem3 style={styles.mt28} />,
    <MenuItem4 style={styles.mt28} />,
    <MenuItem5 style={styles.mt28} />,
    <MenuItem6 style={styles.mt28} />,
  ]);
  const [drawerItemsActive] = useState([
    <MenuItem1 style={styles.mt28} />,
    <MenuItem2 style={styles.mt28} />,
    <MenuItem3 style={styles.mt28} />,
    <MenuItem4 style={styles.mt28} />,
    <MenuItem5 style={styles.mt28} />,
    <MenuItem6 style={styles.mt28} />,
  ]);
  const stateIndex = !state ? 0 : state.index - 1;
  return (
    <SafeAreaView style={styles.drawerMenuSafeAreaView}>
      <View style={styles.view}>
        <View style={styles.menuContainerView}>
          <Pressable
            style={styles.profilePressable}
            onPress={() =>
              navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
            }
          >
            <View style={styles.imageView}>
              <Image
                style={styles.userIconCircle}
                resizeMode="cover"
                source={require("../assets/usericoncircle3.png")}
              />
            </View>
            <View style={[styles.titleView, styles.ml12]}>
              <Text style={styles.helloText}>Hello</Text>
              <Text style={[styles.daisyText, styles.mt_3]}>Daisy</Text>
            </View>
          </Pressable>
          <View style={[styles.lineView, styles.mt20]} />
          <View style={[styles.drawerMenuItems, styles.mt20]}>
            {stateIndex === 0 ? drawerItemsActive[0] : drawerItemsNormal[0]}
            {stateIndex === 1 ? drawerItemsActive[1] : drawerItemsNormal[1]}
            {stateIndex === 2 ? drawerItemsActive[2] : drawerItemsNormal[2]}
            {stateIndex === 3 ? drawerItemsActive[3] : drawerItemsNormal[3]}
            {stateIndex === 4 ? drawerItemsActive[4] : drawerItemsNormal[4]}
            {stateIndex === 5 ? drawerItemsActive[5] : drawerItemsNormal[5]}
          </View>
        </View>
        <View style={styles.authorView}>
          <Text style={styles.someText}>By Priyanshu</Text>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mt_3: {
    marginTop: -3,
  },
  ml12: {
    marginLeft: 12,
  },
  ml16: {
    marginLeft: 16,
  },
  mt28: {
    marginTop: 28,
  },
  mt20: {
    marginTop: 20,
  },
  drawerMenuSafeAreaView: {
    flex: 1,
    backgroundColor: "#fff",
  },
  userIconCircle: {
    position: "relative",
    borderRadius: 30,
    width: 53,
    height: 53,
    flexShrink: 0,
  },
  imageView: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  helloText: {
    position: "relative",
    fontSize: 12,
    lineHeight: 18,
    fontFamily: "Roboto",
    color: "#7e8b97",
    textAlign: "left",
  },
  daisyText: {
    position: "relative",
    fontSize: 20,
    lineHeight: 30,
    fontWeight: "700",
    fontFamily: "Roboto",
    color: "#191919",
    textAlign: "left",
  },
  titleView: {
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  profilePressable: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  lineView: {
    alignSelf: "stretch",
    position: "relative",
    borderStyle: "solid",
    borderColor: "#e6e9f0",
    borderTopWidth: 1,
    height: 1,
    flexShrink: 0,
  },
  drawerMenuItems: {
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  menuContainerView: {
    width: 260,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  someText: {
    position: "relative",
    fontSize: 14,
    lineHeight: 24,
    fontFamily: "Roboto",
    color: "#7e8b97",
    textAlign: "left",
  },
  authorView: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  view: {
    position: "relative",
    backgroundColor: "#fff",
    flex: 1,
    width: "100%",
    height: 792,
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingTop: 40,
    paddingBottom: 20,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
});

export default DrawerMenu;
