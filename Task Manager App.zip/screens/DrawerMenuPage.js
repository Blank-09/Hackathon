import * as React from "react";
import { Image, StyleSheet, View, Text, SafeAreaView } from "react-native";

const DrawerMenuPage = () => {
  return (
    <SafeAreaView style={styles.drawerMenuPage}>
      <View style={styles.view}>
        <View style={styles.menuView}>
          <View style={styles.profileView}>
            <View style={styles.imageView}>
              <Image
                style={styles.userIconCircle}
                resizeMode="cover"
                source={require("../assets/usericoncircle10.png")}
              />
            </View>
            <View style={[styles.titleView, styles.ml12]}>
              <Text style={styles.helloText}>Hello</Text>
              <Text style={[styles.daisyText, styles.mt_3]}>Daisy</Text>
            </View>
          </View>
          <View style={[styles.lineView, styles.mt20]} />
          <View style={[styles.drawerMenuItems, styles.mt20]} />
        </View>
        <View style={styles.authorView}>
          <Text style={styles.someText}>By Priyanshu</Text>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mt_3: {
    marginTop: -3,
  },
  ml12: {
    marginLeft: 12,
  },
  ml16: {
    marginLeft: 16,
  },
  mt28: {
    marginTop: 28,
  },
  mt20: {
    marginTop: 20,
  },
  drawerMenuPage: {
    flex: 1,
    backgroundColor: "#fff",
  },
  userIconCircle: {
    position: "relative",
    borderRadius: 30,
    width: 53,
    height: 53,
    flexShrink: 0,
  },
  imageView: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  helloText: {
    position: "relative",
    fontSize: 12,
    lineHeight: 18,
    fontFamily: "Roboto",
    color: "#7e8b97",
    textAlign: "left",
  },
  daisyText: {
    position: "relative",
    fontSize: 20,
    lineHeight: 30,
    fontWeight: "700",
    fontFamily: "Roboto",
    color: "#191919",
    textAlign: "left",
  },
  titleView: {
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  profileView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  lineView: {
    alignSelf: "stretch",
    position: "relative",
    borderStyle: "solid",
    borderColor: "#e6e9f0",
    borderTopWidth: 1,
    height: 1,
    flexShrink: 0,
  },
  drawerMenuItems: {
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  menuView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  someText: {
    position: "relative",
    fontSize: 14,
    lineHeight: 24,
    fontFamily: "Roboto",
    color: "#7e8b97",
    textAlign: "left",
  },
  authorView: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  view: {
    position: "relative",
    backgroundColor: "#fff",
    flex: 1,
    width: "100%",
    height: 812,
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingTop: 40,
    paddingBottom: 20,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
});

export default DrawerMenuPage;
