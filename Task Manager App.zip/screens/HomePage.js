import * as React from "react";
import {
  StatusBar,
  StyleSheet,
  Pressable,
  Image,
  TouchableOpacity,
  Text,
  View,
  ScrollView,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const HomePage = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homePageView}>
      <StatusBar
        barStyle="light-content"
        translucent={true}
        backgroundColor="#303030"
      />
      <View style={styles.navTopView}>
        <TouchableOpacity
          style={styles.menuBarTouchableOpacity}
          activeOpacity={0.2}
          onPress={() => navigation.toggleDrawer()}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/menubar.png")}
          />
        </TouchableOpacity>
        <Text style={styles.taskManagerText}>Task Manager</Text>
        <Pressable style={styles.userIconCirclePressable} onPress={() => {}} />
      </View>
      <ScrollView
        style={styles.mainBodyScrollView}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.mainBodyScrollViewContent}
      >
        <View style={styles.welcomeTextView}>
          <Text style={styles.headingText} numberOfLines={1}>
            <Text style={styles.helloText}>{`Hello, `}</Text>
            <Text style={styles.daisyText}>Daisy!</Text>
          </Text>
          <Text style={styles.subheadingText}>Having a nice day!</Text>
        </View>
        <View style={[styles.tasksView, styles.mt30]}>
          <ScrollView
            style={styles.tabsScrollView}
            horizontal
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.tabsScrollViewContent}
          >
            <Pressable style={styles.roundedPillPressable} onPress={() => {}}>
              <Text style={styles.textHere}>My tasks</Text>
              <Image
                style={[styles.ellipseIcon, styles.ml10]}
                resizeMode="cover"
                source={require("../assets/ellipse-1.png")}
              />
            </Pressable>
            <Pressable style={[styles.roundedPillPressable1, styles.ml16]}>
              <Text style={styles.textHere1}>Project</Text>
            </Pressable>
            <Pressable style={[styles.roundedPillPressable2, styles.ml16]}>
              <Text style={styles.textHere2}>Project</Text>
            </Pressable>
            <Pressable style={[styles.roundedPillPressable3, styles.ml16]}>
              <Text style={styles.textHere3}>Project</Text>
            </Pressable>
            <Pressable style={[styles.roundedPillPressable4, styles.ml16]}>
              <Text style={styles.textHere4}>Note</Text>
            </Pressable>
            <Pressable style={[styles.roundedPillPressable5, styles.ml16]}>
              <Text style={styles.textHere5}>Note</Text>
            </Pressable>
            <Pressable style={[styles.roundedPillPressable6, styles.ml16]}>
              <Text style={styles.textHere6}>Note</Text>
            </Pressable>
          </ScrollView>
          <ScrollView
            style={styles.cardsCarouselScrollView}
            horizontal
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.cardsCarouselScrollViewContent}
          >
            <View style={styles.cardView}>
              <Image
                style={styles.cardBgIcon}
                resizeMode="cover"
                source={require("../assets/cardbg.png")}
              />
              <View style={styles.cardBodyView}>
                <View style={styles.projectNameView}>
                  <Image
                    style={styles.userIconSquareRounded}
                    resizeMode="cover"
                    source={require("../assets/usericonsquarerounded.png")}
                  />
                  <Text
                    style={[styles.projectZText, styles.ml11]}
                    numberOfLines={2}
                  >
                    Project Z
                  </Text>
                </View>
                <Text
                  style={[styles.backEndDevelopment, styles.mt30]}
                  numberOfLines={3}
                >
                  Back End Development
                </Text>
                <Text
                  style={[styles.october2022Text, styles.mt30]}
                  numberOfLines={1}
                >
                  October 2022
                </Text>
              </View>
            </View>
            <View style={[styles.cardView1, styles.ml25]}>
              <Image
                style={styles.cardBgIcon1}
                resizeMode="cover"
                source={require("../assets/cardbg1.png")}
              />
              <View style={styles.cardBodyView1}>
                <View style={styles.projectNameView1}>
                  <Image
                    style={styles.userIconSquareRounded1}
                    resizeMode="cover"
                    source={require("../assets/usericonsquarerounded.png")}
                  />
                  <Text
                    style={[styles.projectZText1, styles.ml11]}
                    numberOfLines={2}
                  >
                    Project X
                  </Text>
                </View>
                <Text
                  style={[styles.backEndDevelopment1, styles.mt30]}
                  numberOfLines={3}
                >
                  UI Design
                </Text>
                <Text
                  style={[styles.october2022Text1, styles.mt30]}
                  numberOfLines={1}
                >
                  November 2022
                </Text>
              </View>
            </View>
            <View style={[styles.cardView2, styles.ml25]}>
              <Image
                style={styles.cardBgIcon2}
                resizeMode="cover"
                source={require("../assets/cardbg2.png")}
              />
              <View style={styles.cardBodyView2}>
                <View style={styles.projectNameView2}>
                  <Image
                    style={styles.userIconSquareRounded2}
                    resizeMode="cover"
                    source={require("../assets/usericonsquarerounded2.png")}
                  />
                  <Text
                    style={[styles.projectZText2, styles.ml11]}
                    numberOfLines={2}
                  >
                    Project X
                  </Text>
                </View>
                <Text
                  style={[styles.backEndDevelopment2, styles.mt30]}
                  numberOfLines={3}
                >
                  UI Design
                </Text>
                <Text
                  style={[styles.october2022Text2, styles.mt30]}
                  numberOfLines={1}
                >
                  November 2022
                </Text>
              </View>
            </View>
            <View style={[styles.cardView3, styles.ml25]}>
              <Image
                style={styles.cardBgIcon3}
                resizeMode="cover"
                source={require("../assets/cardbg2.png")}
              />
              <View style={styles.cardBodyView3}>
                <View style={styles.projectNameView3}>
                  <Image
                    style={styles.userIconSquareRounded3}
                    resizeMode="cover"
                    source={require("../assets/usericonsquarerounded2.png")}
                  />
                  <Text
                    style={[styles.projectZText3, styles.ml11]}
                    numberOfLines={2}
                  >
                    Project X
                  </Text>
                </View>
                <Text
                  style={[styles.backEndDevelopment3, styles.mt30]}
                  numberOfLines={3}
                >
                  UI Design
                </Text>
                <Text
                  style={[styles.october2022Text3, styles.mt30]}
                  numberOfLines={1}
                >
                  November 2022
                </Text>
              </View>
            </View>
          </ScrollView>
        </View>
        <View style={[styles.inProgressTaskView, styles.mt30]}>
          <View style={styles.headerView}>
            <Text style={styles.progressText}>Progress</Text>
            <Image
              style={styles.moreHorizontalIcon}
              resizeMode="cover"
              source={require("../assets/morehorizontal.png")}
            />
          </View>
          <View style={[styles.progressListView, styles.mt20]}>
            <Pressable
              style={styles.progressListItemPressable}
              onPress={() => {}}
            >
              <View style={styles.moreVerticalView} />
              <Image
                style={[styles.userIconCircle, styles.ml16]}
                resizeMode="cover"
                source={require("../assets/usericoncircle.png")}
              />
              <View style={[styles.progressDetailsView, styles.ml16]}>
                <Text style={styles.projectNameText} numberOfLines={1}>
                  Grossary List
                </Text>
                <Text style={styles.timePassedText}>2 days ago</Text>
              </View>
              <Pressable
                style={[styles.moreVerticalPressable, styles.ml16]}
                onPress={() => {}}
              >
                <Image
                  style={styles.icon1}
                  resizeMode="cover"
                  source={require("../assets/morevertical.png")}
                />
              </Pressable>
            </Pressable>
            <Pressable
              style={[styles.progressListItemPressable1, styles.mt21]}
              onPress={() => {}}
            >
              <View style={styles.moreVerticalView1} />
              <Image
                style={[styles.userIconCircle1, styles.ml16]}
                resizeMode="cover"
                source={require("../assets/usericoncircle1.png")}
              />
              <View style={[styles.progressDetailsView1, styles.ml16]}>
                <Text style={styles.projectNameText1} numberOfLines={1}>
                  Make a search in Google
                </Text>
                <Text style={styles.timePassedText1}>3 days ago</Text>
              </View>
              <Pressable
                style={[styles.moreVerticalPressable1, styles.ml16]}
                onPress={() => {}}
              >
                <Image
                  style={styles.icon2}
                  resizeMode="cover"
                  source={require("../assets/morevertical1.png")}
                />
              </Pressable>
            </Pressable>
            <Pressable
              style={[styles.progressListItemPressable2, styles.mt21]}
              onPress={() => {}}
            >
              <View style={styles.moreVerticalView2} />
              <Image
                style={[styles.userIconCircle2, styles.ml16]}
                resizeMode="cover"
                source={require("../assets/usericoncircle2.png")}
              />
              <View style={[styles.progressDetailsView2, styles.ml16]}>
                <Text style={styles.projectNameText2} numberOfLines={1}>
                  Go for Piano Class
                </Text>
                <Text style={styles.timePassedText2}>3 days ago</Text>
              </View>
              <Pressable
                style={[styles.moreVerticalPressable2, styles.ml16]}
                onPress={() => {}}
              >
                <Image
                  style={styles.icon3}
                  resizeMode="cover"
                  source={require("../assets/morevertical2.png")}
                />
              </Pressable>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  ml10: {
    marginLeft: 10,
  },
  ml16: {
    marginLeft: 16,
  },
  tabsScrollViewContent: {
    alignItems: "flex-start",
    justifyContent: "flex-start",
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingTop: 3,
    paddingBottom: 12,
  },
  ml11: {
    marginLeft: 11,
  },
  mt30: {
    marginTop: 30,
  },
  ml25: {
    marginLeft: 25,
  },
  cardsCarouselScrollViewContent: {
    alignItems: "center",
    justifyContent: "flex-start",
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 12,
  },
  mt21: {
    marginTop: 21,
  },
  mt20: {
    marginTop: 20,
  },
  mainBodyScrollViewContent: {
    alignItems: "center",
    justifyContent: "flex-start",
    flexDirection: "column",
    paddingHorizontal: 0,
    paddingVertical: 20,
  },
  ml45: {
    marginLeft: 45,
  },
  icon: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  menuBarTouchableOpacity: {
    position: "relative",
  },
  taskManagerText: {
    position: "relative",
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Roboto",
    color: "#000",
    textAlign: "center",
  },
  userIconCirclePressable: {
    position: "relative",
    width: 5,
    height: 24,
    flexShrink: 0,
  },
  navTopView: {
    alignSelf: "stretch",
    borderBottomRightRadius: 10,
    borderBottomLeftRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "rgba(211, 211, 211, 0.2)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 20,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "space-between",
  },
  helloText: {
    fontFamily: "Open Sans",
  },
  daisyText: {
    fontWeight: "700",
    fontFamily: "Open Sans",
  },
  headingText: {
    position: "relative",
    fontSize: 32,
    color: "#000",
    textAlign: "left",
    width: 330,
  },
  subheadingText: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 16,
    letterSpacing: 1.6,
    fontWeight: "300",
    fontFamily: "Open Sans",
    color: "#555",
    textAlign: "left",
    textIndent: 1,
  },
  welcomeTextView: {
    alignSelf: "stretch",
    height: 74.04,
    flexShrink: 0,
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingVertical: 0,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  textHere: {
    position: "relative",
    fontSize: 10,
    fontWeight: "700",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "center",
  },
  ellipseIcon: {
    position: "relative",
    width: 4,
    height: 4,
    flexShrink: 0,
  },
  roundedPillPressable: {
    borderRadius: 30,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 24,
    paddingVertical: 11,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  textHere1: {
    position: "relative",
    fontSize: 10,
    fontWeight: "300",
    fontFamily: "Open Sans",
    color: "#646464",
    textAlign: "center",
  },
  roundedPillPressable1: {
    borderRadius: 30,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 22,
    paddingVertical: 11,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  textHere2: {
    position: "relative",
    fontSize: 10,
    fontWeight: "300",
    fontFamily: "Open Sans",
    color: "#646464",
    textAlign: "center",
  },
  roundedPillPressable2: {
    borderRadius: 30,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 22,
    paddingVertical: 11,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  textHere3: {
    position: "relative",
    fontSize: 10,
    fontWeight: "300",
    fontFamily: "Open Sans",
    color: "#646464",
    textAlign: "center",
  },
  roundedPillPressable3: {
    borderRadius: 30,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 22,
    paddingVertical: 11,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  textHere4: {
    position: "relative",
    fontSize: 10,
    fontWeight: "300",
    fontFamily: "Open Sans",
    color: "#646464",
    textAlign: "center",
  },
  roundedPillPressable4: {
    borderRadius: 30,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 22,
    paddingVertical: 11,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  textHere5: {
    position: "relative",
    fontSize: 10,
    fontWeight: "300",
    fontFamily: "Open Sans",
    color: "#646464",
    textAlign: "center",
  },
  roundedPillPressable5: {
    borderRadius: 30,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 22,
    paddingVertical: 11,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  textHere6: {
    position: "relative",
    fontSize: 10,
    fontWeight: "300",
    fontFamily: "Open Sans",
    color: "#646464",
    textAlign: "center",
  },
  roundedPillPressable6: {
    borderRadius: 30,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 22,
    paddingVertical: 11,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  tabsScrollView: {
    boxSizing: "border-box",
    width: "100%",
  },
  cardBgIcon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 357.55,
    height: 342.56,
  },
  userIconSquareRounded: {
    position: "relative",
    borderRadius: 8,
    width: 36,
    height: 36,
    flexShrink: 0,
  },
  projectZText: {
    flex: 1,
    position: "relative",
    fontSize: 14,
    letterSpacing: -0.3,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  projectNameView: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  backEndDevelopment: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 18,
    lineHeight: 27,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
    height: 74.43,
  },
  october2022Text: {
    position: "relative",
    fontSize: 13,
    letterSpacing: -0.3,
    lineHeight: 21,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  cardBodyView: {
    position: "absolute",
    top: -0.06,
    left: 0,
    width: 195,
    height: 256,
    flexDirection: "column",
    paddingHorizontal: 22,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  cardView: {
    position: "relative",
    borderRadius: 28,
    backgroundColor: "#6040f8",
    shadowColor: "rgba(96, 64, 248, 0.3)",
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 198,
    height: 256,
    flexShrink: 0,
    overflow: "hidden",
  },
  cardBgIcon1: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 357.55,
    height: 342.56,
  },
  userIconSquareRounded1: {
    position: "relative",
    borderRadius: 8,
    width: 36,
    height: 36,
    flexShrink: 0,
  },
  projectZText1: {
    flex: 1,
    position: "relative",
    fontSize: 14,
    letterSpacing: -0.3,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  projectNameView1: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  backEndDevelopment1: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 18,
    lineHeight: 27,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
    height: 74.43,
  },
  october2022Text1: {
    position: "relative",
    fontSize: 13,
    letterSpacing: -0.3,
    lineHeight: 21,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  cardBodyView1: {
    position: "absolute",
    top: -0.06,
    left: 0,
    width: 195,
    height: 256,
    flexDirection: "column",
    paddingHorizontal: 22,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  cardView1: {
    position: "relative",
    borderRadius: 28,
    backgroundColor: "#6040f8",
    shadowColor: "rgba(96, 64, 248, 0.3)",
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 198,
    height: 256,
    flexShrink: 0,
    overflow: "hidden",
  },
  cardBgIcon2: {
    position: "absolute",
    top: -39,
    left: -79.22,
    width: 357.55,
    height: 342.56,
  },
  userIconSquareRounded2: {
    position: "relative",
    borderRadius: 8,
    width: 36,
    height: 36,
    flexShrink: 0,
  },
  projectZText2: {
    flex: 1,
    position: "relative",
    fontSize: 14,
    letterSpacing: -0.3,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  projectNameView2: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  backEndDevelopment2: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 18,
    lineHeight: 27,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
    height: 74.43,
  },
  october2022Text2: {
    position: "relative",
    fontSize: 13,
    letterSpacing: -0.3,
    lineHeight: 21,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  cardBodyView2: {
    position: "absolute",
    top: -0.06,
    left: 0,
    width: 195,
    height: 256,
    flexDirection: "column",
    paddingHorizontal: 22,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  cardView2: {
    position: "relative",
    borderRadius: 28,
    backgroundColor: "#6040f8",
    shadowColor: "rgba(96, 64, 248, 0.3)",
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 198,
    height: 256,
    flexShrink: 0,
    overflow: "hidden",
  },
  cardBgIcon3: {
    position: "absolute",
    top: -39,
    left: -79.22,
    width: 357.55,
    height: 342.56,
  },
  userIconSquareRounded3: {
    position: "relative",
    borderRadius: 8,
    width: 36,
    height: 36,
    flexShrink: 0,
  },
  projectZText3: {
    flex: 1,
    position: "relative",
    fontSize: 14,
    letterSpacing: -0.3,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  projectNameView3: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  backEndDevelopment3: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 18,
    lineHeight: 27,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
    height: 74.43,
  },
  october2022Text3: {
    position: "relative",
    fontSize: 13,
    letterSpacing: -0.3,
    lineHeight: 21,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  cardBodyView3: {
    position: "absolute",
    top: -0.06,
    left: 0,
    width: 195,
    height: 256,
    flexDirection: "column",
    paddingHorizontal: 22,
    paddingVertical: 10,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  cardView3: {
    position: "relative",
    borderRadius: 28,
    backgroundColor: "#6040f8",
    shadowColor: "rgba(96, 64, 248, 0.3)",
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 198,
    height: 256,
    flexShrink: 0,
    overflow: "hidden",
  },
  cardsCarouselScrollView: {
    boxSizing: "border-box",
    width: "100%",
  },
  tasksView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  progressText: {
    position: "relative",
    fontSize: 20,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  moreHorizontalIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  headerView: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  moreVerticalView: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon1: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable: {
    position: "relative",
  },
  progressListItemPressable: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  moreVerticalView1: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle1: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText1: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText1: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView1: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon2: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable1: {
    position: "relative",
  },
  progressListItemPressable1: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  moreVerticalView2: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle2: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText2: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText2: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView2: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon3: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable2: {
    position: "relative",
  },
  progressListItemPressable2: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  progressListView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  inProgressTaskView: {
    alignSelf: "stretch",
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingVertical: 0,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  mainBodyScrollView: {
    alignSelf: "stretch",
    boxSizing: "border-box",
    flex: 1,
  },
  homePageView: {
    position: "relative",
    backgroundColor: "#f1f4ff",
    flex: 1,
    width: "100%",
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
});

export default HomePage;
