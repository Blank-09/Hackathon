import * as React from "react";
import {
  StatusBar,
  StyleSheet,
  Pressable,
  Image,
  Text,
  View,
  ScrollView,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const SearchTask = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.searchTaskView}>
      <StatusBar
        barStyle="light-content"
        translucent={true}
        backgroundColor="#303030"
      />
      <View style={styles.navBarView}>
        <Pressable
          style={styles.arrowLeftPressable}
          onPress={() => navigation.goBack()}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/arrowleft.png")}
          />
        </Pressable>
        <Text style={styles.taskManagerText}>Search Task</Text>
        <Pressable
          style={styles.xPressable}
          onPress={() => navigation.goBack()}
        >
          <Image
            style={styles.icon1}
            resizeMode="cover"
            source={require("../assets/x.png")}
          />
        </Pressable>
      </View>
      <ScrollView
        style={styles.mainBodyScrollView}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.mainBodyScrollViewContent}
      >
        <View style={styles.inputContainerView}>
          <View style={styles.dateTimePicker}>
            <Text style={styles.searchText}>Search</Text>
            <View style={[styles.contentView, styles.mt7]}>
              <Text style={styles.meetingText}>Meeting</Text>
              <Image
                style={[styles.searchIcon, styles.ml8]}
                resizeMode="cover"
                source={require("../assets/search.png")}
              />
            </View>
            <View style={[styles.lineView, styles.mt7]} />
          </View>
          <View style={[styles.inProgressTaskView, styles.mt32]}>
            <View style={styles.headerView}>
              <Text style={styles.progressText}>Search Results</Text>
              <Image
                style={styles.moreHorizontalIcon}
                resizeMode="cover"
                source={require("../assets/morehorizontal1.png")}
              />
            </View>
            <View style={[styles.progressListView, styles.mt20]}>
              <Pressable
                style={styles.progressListItemPressable}
                onPress={() => {}}
              >
                <View style={styles.moreVerticalView} />
                <Image
                  style={[styles.userIconCircle, styles.ml16]}
                  resizeMode="cover"
                  source={require("../assets/usericoncircle4.png")}
                />
                <View style={[styles.progressDetailsView, styles.ml16]}>
                  <Text style={styles.projectNameText} numberOfLines={1}>
                    My Next Meeting
                  </Text>
                  <Text style={styles.timePassedText}>2 days ago</Text>
                </View>
                <Pressable
                  style={[styles.moreVerticalPressable, styles.ml16]}
                  onPress={() => {}}
                >
                  <Image
                    style={styles.icon2}
                    resizeMode="cover"
                    source={require("../assets/morevertical3.png")}
                  />
                </Pressable>
              </Pressable>
              <Pressable
                style={[styles.progressListItemPressable1, styles.mt21]}
                onPress={() => {}}
              >
                <View style={styles.moreVerticalView1} />
                <Image
                  style={[styles.userIconCircle1, styles.ml16]}
                  resizeMode="cover"
                  source={require("../assets/usericoncircle5.png")}
                />
                <View style={[styles.progressDetailsView1, styles.ml16]}>
                  <Text style={styles.projectNameText1} numberOfLines={1}>
                    Meeting at office
                  </Text>
                  <Text style={styles.timePassedText1}>3 days ago</Text>
                </View>
                <Pressable
                  style={[styles.moreVerticalPressable1, styles.ml16]}
                  onPress={() => {}}
                >
                  <Image
                    style={styles.icon3}
                    resizeMode="cover"
                    source={require("../assets/morevertical4.png")}
                  />
                </Pressable>
              </Pressable>
              <Pressable
                style={[styles.progressListItemPressable2, styles.mt21]}
                onPress={() => {}}
              >
                <View style={styles.moreVerticalView2} />
                <Image
                  style={[styles.userIconCircle2, styles.ml16]}
                  resizeMode="cover"
                  source={require("../assets/usericoncircle6.png")}
                />
                <View style={[styles.progressDetailsView2, styles.ml16]}>
                  <Text style={styles.projectNameText2} numberOfLines={1}>
                    Friends Meeting
                  </Text>
                  <Text style={styles.timePassedText2}>3 days ago</Text>
                </View>
                <Pressable
                  style={[styles.moreVerticalPressable2, styles.ml16]}
                  onPress={() => {}}
                >
                  <Image
                    style={styles.icon4}
                    resizeMode="cover"
                    source={require("../assets/morevertical5.png")}
                  />
                </Pressable>
              </Pressable>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  ml8: {
    marginLeft: 8,
  },
  mt7: {
    marginTop: 7,
  },
  ml16: {
    marginLeft: 16,
  },
  mt21: {
    marginTop: 21,
  },
  mt20: {
    marginTop: 20,
  },
  mt32: {
    marginTop: 32,
  },
  mainBodyScrollViewContent: {
    alignItems: "flex-start",
    justifyContent: "flex-start",
    flexDirection: "column",
  },
  ml45: {
    marginLeft: 45,
  },
  icon: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  arrowLeftPressable: {
    position: "relative",
  },
  taskManagerText: {
    position: "relative",
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Roboto",
    color: "#000",
    textAlign: "center",
  },
  icon1: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  xPressable: {
    position: "relative",
  },
  navBarView: {
    alignSelf: "stretch",
    backgroundColor: "#fff",
    shadowColor: "rgba(215, 215, 215, 0.25)",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 20,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "space-between",
  },
  searchText: {
    position: "relative",
    fontSize: 12,
    letterSpacing: 0.15,
    lineHeight: 12,
    fontFamily: "Roboto",
    color: "#000",
    textAlign: "left",
  },
  meetingText: {
    flex: 1,
    position: "relative",
    fontSize: 16,
    letterSpacing: 0.15,
    lineHeight: 24,
    fontFamily: "Roboto",
    color: "rgba(0, 0, 0, 0.87)",
    textAlign: "left",
  },
  searchIcon: {
    position: "relative",
    width: 28,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
  },
  contentView: {
    alignSelf: "stretch",
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  lineView: {
    alignSelf: "stretch",
    position: "relative",
    borderStyle: "solid",
    borderColor: "rgba(0, 0, 0, 0.3)",
    borderWidth: 1,
    height: 2,
    flexShrink: 0,
  },
  dateTimePicker: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  progressText: {
    position: "relative",
    fontSize: 20,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  moreHorizontalIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  headerView: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  moreVerticalView: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon2: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable: {
    position: "relative",
  },
  progressListItemPressable: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  moreVerticalView1: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle1: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText1: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText1: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView1: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon3: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable1: {
    position: "relative",
  },
  progressListItemPressable1: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  moreVerticalView2: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle2: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText2: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText2: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView2: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon4: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable2: {
    position: "relative",
  },
  progressListItemPressable2: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  progressListView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  inProgressTaskView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  inputContainerView: {
    alignSelf: "stretch",
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingVertical: 40,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  mainBodyScrollView: {
    alignSelf: "stretch",
    flex: 1,
  },
  searchTaskView: {
    position: "relative",
    backgroundColor: "#fff",
    flex: 1,
    width: "100%",
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
});

export default SearchTask;
