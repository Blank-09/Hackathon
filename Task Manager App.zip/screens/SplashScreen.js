import * as React from "react";
import { Image, StyleSheet, View } from "react-native";

const SplashScreen = () => {
  return (
    <View style={styles.splashScreenView}>
      <Image
        style={styles.frameIcon}
        resizeMode="cover"
        source={require("../assets/frame.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  frameIcon: {
    flex: 1,
    alignSelf: "stretch",
    position: "relative",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  splashScreenView: {
    position: "relative",
    backgroundColor: "#5e41fc",
    flex: 1,
    width: "100%",
    height: 844,
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default SplashScreen;
