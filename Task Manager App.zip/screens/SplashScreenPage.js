import * as React from "react";
import { Image, StyleSheet, View } from "react-native";

const SplashScreenPage = () => {
  return (
    <View style={styles.splashScreenPage}>
      <View style={styles.frameView}>
        <Image
          style={styles.bgIcon}
          resizeMode="cover"
          source={require("../assets/bg.png")}
        />
        <Image
          style={styles.vectorIcon}
          resizeMode="cover"
          source={require("../assets/vector.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  bgIcon: {
    position: "absolute",
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  vectorIcon: {
    position: "absolute",
    transform: [
      {
        translateY: 0,
      },
      {
        translateX: -101.07,
      },
    ],
    top: "50%",
    left: "50%",
    width: 202.14,
    height: 31.8,
  },
  frameView: {
    flex: 1,
    alignSelf: "stretch",
    position: "relative",
  },
  splashScreenPage: {
    position: "relative",
    backgroundColor: "#5e41fc",
    flex: 1,
    width: "100%",
    height: 864,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default SplashScreenPage;
