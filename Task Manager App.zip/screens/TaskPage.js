import * as React from "react";
import {
  StatusBar,
  StyleSheet,
  Pressable,
  Image,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const TaskPage = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.taskPageView}>
      <StatusBar
        barStyle="light-content"
        translucent={true}
        backgroundColor="#303030"
      />
      <View style={styles.navBarView}>
        <Pressable
          style={styles.arrowLeftPressable}
          onPress={() => navigation.goBack()}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/arrowleft.png")}
          />
        </Pressable>
        <Text style={styles.taskManagerText}>Task Manager</Text>
        <Image
          style={styles.searchIcon}
          resizeMode="cover"
          source={require("../assets/search1.png")}
        />
      </View>
      <ScrollView
        style={styles.mainBodyScrollView}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.mainBodyScrollViewContent}
      >
        <View style={styles.headerView1}>
          <View style={styles.headerView}>
            <Text style={styles.taskMonthYearText}>Oct, 2020</Text>
            <TouchableOpacity
              style={styles.addTaskBtnTouchableOpacity}
              activeOpacity={0.95}
              onPress={() =>
                navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
              }
            >
              <Image
                style={styles.plusIcon}
                resizeMode="cover"
                source={require("../assets/plus.png")}
              />
              <Text style={[styles.addTaskText, styles.ml4]}>Add Task</Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.dateDayView, styles.mt35]}>
            <Pressable style={styles.dateDayBtnPressable}>
              <Text style={styles.text}>10</Text>
              <Text style={[styles.monText, styles.mt_2]}>Mon</Text>
            </Pressable>
            <Pressable style={styles.dateDayBtnPressable1}>
              <Text style={styles.text1}>11</Text>
              <Text style={[styles.monText1, styles.mt_2]}>Tue</Text>
            </Pressable>
            <Pressable style={styles.dateDayBtnPressable2}>
              <Text style={styles.text2}>12</Text>
              <Text style={[styles.monText2, styles.mt_2]}>Wed</Text>
            </Pressable>
            <Pressable style={styles.dateDayBtnPressable3}>
              <Text style={styles.text3}>13</Text>
              <Text style={[styles.monText3, styles.mt_2]}>Thu</Text>
            </Pressable>
          </View>
        </View>
        <View style={[styles.inProgressTaskView, styles.mt30]}>
          <View style={styles.headerView2}>
            <Text style={styles.progressText}>Task</Text>
            <Image
              style={styles.moreHorizontalIcon}
              resizeMode="cover"
              source={require("../assets/morehorizontal2.png")}
            />
          </View>
          <View style={[styles.progressListView, styles.mt20]}>
            <Pressable
              style={styles.progressListItemPressable}
              onPress={() => {}}
            >
              <View style={styles.moreVerticalView} />
              <Image
                style={[styles.userIconCircle, styles.ml16]}
                resizeMode="cover"
                source={require("../assets/usericoncircle7.png")}
              />
              <View style={[styles.progressDetailsView, styles.ml16]}>
                <Text style={styles.projectNameText} numberOfLines={1}>
                  Grossary List
                </Text>
                <Text style={styles.timePassedText}>2 days ago</Text>
              </View>
              <Pressable
                style={[styles.moreVerticalPressable, styles.ml16]}
                onPress={() => {}}
              >
                <Image
                  style={styles.icon1}
                  resizeMode="cover"
                  source={require("../assets/morevertical6.png")}
                />
              </Pressable>
            </Pressable>
            <Pressable
              style={[styles.progressListItemPressable1, styles.mt21]}
              onPress={() => {}}
            >
              <View style={styles.moreVerticalView1} />
              <Image
                style={[styles.userIconCircle1, styles.ml16]}
                resizeMode="cover"
                source={require("../assets/usericoncircle8.png")}
              />
              <View style={[styles.progressDetailsView1, styles.ml16]}>
                <Text style={styles.projectNameText1} numberOfLines={1}>
                  Make a search in Google
                </Text>
                <Text style={styles.timePassedText1}>3 days ago</Text>
              </View>
              <Pressable
                style={[styles.moreVerticalPressable1, styles.ml16]}
                onPress={() => {}}
              >
                <Image
                  style={styles.icon2}
                  resizeMode="cover"
                  source={require("../assets/morevertical7.png")}
                />
              </Pressable>
            </Pressable>
            <Pressable
              style={[styles.progressListItemPressable2, styles.mt21]}
              onPress={() => {}}
            >
              <View style={styles.moreVerticalView2} />
              <Image
                style={[styles.userIconCircle2, styles.ml16]}
                resizeMode="cover"
                source={require("../assets/usericoncircle9.png")}
              />
              <View style={[styles.progressDetailsView2, styles.ml16]}>
                <Text style={styles.projectNameText2} numberOfLines={1}>
                  Go for Piano Class
                </Text>
                <Text style={styles.timePassedText2}>3 days ago</Text>
              </View>
              <Pressable
                style={[styles.moreVerticalPressable2, styles.ml16]}
                onPress={() => {}}
              >
                <Image
                  style={styles.icon3}
                  resizeMode="cover"
                  source={require("../assets/morevertical8.png")}
                />
              </Pressable>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  ml4: {
    marginLeft: 4,
  },
  mt_2: {
    marginTop: -2,
  },
  mt35: {
    marginTop: 35,
  },
  ml16: {
    marginLeft: 16,
  },
  mt21: {
    marginTop: 21,
  },
  mt20: {
    marginTop: 20,
  },
  mt30: {
    marginTop: 30,
  },
  mainBodyScrollViewContent: {
    alignItems: "center",
    justifyContent: "flex-start",
    flexDirection: "column",
    paddingHorizontal: 0,
    paddingBottom: 20,
  },
  ml45: {
    marginLeft: 45,
  },
  icon: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  arrowLeftPressable: {
    position: "relative",
  },
  taskManagerText: {
    position: "relative",
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Roboto",
    color: "#000",
    textAlign: "center",
  },
  searchIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  navBarView: {
    alignSelf: "stretch",
    backgroundColor: "#fff",
    flexDirection: "row",
    paddingHorizontal: 30,
    paddingVertical: 20,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "space-between",
    zIndex: 2,
  },
  taskMonthYearText: {
    position: "relative",
    fontSize: 32,
    fontWeight: "700",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    width: 210,
    height: 44.7,
  },
  plusIcon: {
    position: "relative",
    width: 15,
    height: 15,
    flexShrink: 0,
    overflow: "hidden",
  },
  addTaskText: {
    position: "relative",
    fontSize: 13,
    fontWeight: "700",
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  addTaskBtnTouchableOpacity: {
    borderRadius: 5,
    backgroundColor: "#5e41fc",
    borderStyle: "solid",
    borderColor: "#4e00e2",
    borderWidth: 1,
    position: "relative",
    flexDirection: "row",
    paddingHorizontal: 10,
    paddingVertical: 8,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  headerView: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  text: {
    position: "relative",
    fontSize: 18,
    fontWeight: "700",
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  monText: {
    position: "relative",
    fontSize: 13,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  dateDayBtnPressable: {
    borderRadius: 8,
    backgroundColor: "#6040f8",
    shadowColor: "rgba(96, 64, 248, 0.51)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    borderStyle: "solid",
    borderColor: "#4e00e2",
    borderWidth: 1,
    position: "relative",
    width: 70,
    height: 70,
    flexShrink: 0,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  text1: {
    position: "relative",
    fontSize: 18,
    fontWeight: "700",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  monText1: {
    position: "relative",
    fontSize: 13,
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  dateDayBtnPressable1: {
    borderRadius: 18,
    width: 70,
    height: 70,
    flexShrink: 0,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  text2: {
    position: "relative",
    fontSize: 18,
    fontWeight: "700",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  monText2: {
    position: "relative",
    fontSize: 13,
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  dateDayBtnPressable2: {
    borderRadius: 18,
    width: 70,
    height: 70,
    flexShrink: 0,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  text3: {
    position: "relative",
    fontSize: 18,
    fontWeight: "700",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  monText3: {
    position: "relative",
    fontSize: 13,
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  dateDayBtnPressable3: {
    borderRadius: 18,
    width: 70,
    height: 70,
    flexShrink: 0,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  dateDayView: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerView1: {
    alignSelf: "stretch",
    borderBottomRightRadius: 50,
    borderBottomLeftRadius: 50,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingTop: 15,
    paddingBottom: 50,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "center",
  },
  progressText: {
    position: "relative",
    fontSize: 20,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  moreHorizontalIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  headerView2: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  moreVerticalView: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon1: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable: {
    position: "relative",
  },
  progressListItemPressable: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  moreVerticalView1: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle1: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText1: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText1: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView1: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon2: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable1: {
    position: "relative",
  },
  progressListItemPressable1: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  moreVerticalView2: {
    position: "relative",
    borderRadius: 10,
    backgroundColor: "#2740dc",
    width: 5,
    height: 28,
    flexShrink: 0,
    overflow: "hidden",
    display: "none",
  },
  userIconCircle2: {
    position: "relative",
    borderRadius: 30,
    width: 49,
    height: 49,
    flexShrink: 0,
  },
  projectNameText2: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 15,
    fontWeight: "600",
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  timePassedText2: {
    alignSelf: "stretch",
    position: "relative",
    fontSize: 11,
    fontFamily: "Open Sans",
    color: "#bcc4d8",
    textAlign: "left",
    textIndent: 1,
  },
  progressDetailsView2: {
    flex: 1,
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
  },
  icon3: {
    width: 24,
    height: 24,
    flexShrink: 0,
    overflow: "hidden",
  },
  moreVerticalPressable2: {
    position: "relative",
  },
  progressListItemPressable2: {
    alignSelf: "stretch",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(192, 209, 255, 0.41)",
    shadowOffset: {
      width: 3,
      height: 3,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    height: 87.01,
    flexShrink: 0,
    flexDirection: "row",
    paddingLeft: 15,
    paddingTop: 17,
    paddingRight: 3,
    paddingBottom: 17,
    boxSizing: "border-box",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  progressListView: {
    alignSelf: "stretch",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  inProgressTaskView: {
    alignSelf: "stretch",
    flexDirection: "column",
    paddingHorizontal: 30,
    paddingVertical: 0,
    boxSizing: "border-box",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  mainBodyScrollView: {
    alignSelf: "stretch",
    boxSizing: "border-box",
    flex: 1,
    zIndex: 1,
  },
  taskPageView: {
    position: "relative",
    backgroundColor: "#f1f4ff",
    flex: 1,
    width: "100%",
    overflow: "hidden",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
});

export default TaskPage;
